package com.dislab.leocai.spacesync.ui;

@Deprecated
public interface RealTimeChartMultiClient {

	void plotMuti(double[][] tracked_hori_lacc);

}
