package com.dislab.leocai.spacesync.utils;



/**
 * Created by leocai on 15-12-23.
 */
public interface RollApplyFunc {

	double[] apply(double[][] buffer, int start, int end);
}
