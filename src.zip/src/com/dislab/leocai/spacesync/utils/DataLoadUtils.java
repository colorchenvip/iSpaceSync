package com.dislab.leocai.spacesync.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import com.dislab.leocai.spacesync.core.model.SensorDataSequnce;


/**
 * 读取csv文件工具类
 * @author leocai
 *
 */
public class DataLoadUtils {

	public static SensorDataSequnce loadSensorData(String fileName) throws IOException {
		FileReader fileReader = new FileReader(new File(fileName));
		String newLine = null;
		int[] ids = new int[] { 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 20 };
		LineNumberReader lnr = new LineNumberReader(fileReader);
		lnr.skip(Long.MAX_VALUE);
		int lineNumber = lnr.getLineNumber();
		double[][] totalDatas = new double[lineNumber - 1][ids.length];
		lnr.close();
		BufferedReader bufferedReader = new BufferedReader(new FileReader(new File(fileName)));
		bufferedReader.readLine(); // title;
		int k = 0;
		while ((newLine = bufferedReader.readLine()) != null) {
			String[] str_line = newLine.split(",");
			double[] singleData = new double[ids.length];
			for (int i = 0; i < ids.length; i++) {
				singleData[i] = Double.parseDouble(str_line[ids[i]]);
			}
			totalDatas[k++] = singleData;
		}
		SensorDataSequnce sensorData = new SensorDataSequnce(totalDatas);
		bufferedReader.close();
		return sensorData;
	}

}
