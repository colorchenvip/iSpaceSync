package com.dislab.leocai.spacesync.transformation;

public interface DealWithRotationMatrix_B2G {

	void deal(int index, double[][] cuMatrix_b2g);

}
