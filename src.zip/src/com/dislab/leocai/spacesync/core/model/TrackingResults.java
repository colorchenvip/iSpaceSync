package com.dislab.leocai.spacesync.core.model;


public class TrackingResults {

}
