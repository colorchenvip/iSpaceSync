package com.dislab.leocai.spacesync.core;

public interface ConsistantAccListener {

	void dealWithClientGlobalAcc(int clientId, double[][] tracked_hori_lacc);

}
