package com.dislab.leocai.spacesync.core;

public interface GlobalLinearAccListener {

	void dealWithConsistant(double[] fc);

}
