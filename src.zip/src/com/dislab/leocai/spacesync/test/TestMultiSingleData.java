package com.dislab.leocai.spacesync.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;


public class TestMultiSingleData {

	public static void main(String[] args) {
//		SingleMultiClientData singleMultiClientData;
//		List<String> clients = new ArrayList<>();
//		clients.add("0");
//		clients.add("1");
//		clients.add("2");
//		singleMultiClientData = new SingleMultiClientData(clients);
//		Random rdm = new Random();
//		int d = 0;
//		for (int i = 0; i < 1000; i++) {
//			ClientData clientData = new ClientData("" + rdm.nextInt(3), new double[] { 1+rdm.nextInt(3), 1+rdm.nextInt(3), 1+rdm.nextInt(3) });
//			if (singleMultiClientData.add(clientData)) {
//				double[] k = singleMultiClientData.get();
//				System.out.println(Arrays.toString(k));
//				d++;
//
//			}
//		}
//		System.out.println(d);

	}

}
